package com.abdullahataya.fooddistribution;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.util.Base64;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.PluginMethod;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@CapacitorPlugin(
    name = "ThermalPrinter",
    permissions = {
        @Permission(alias = "bluetoothConnect", strings = { Manifest.permission.BLUETOOTH_CONNECT }),
        @Permission(alias = "bluetoothScan", strings = { Manifest.permission.BLUETOOTH_SCAN })
    }
)
public class ThermalPrinterPlugin extends Plugin {
    private BluetoothSocket socket;
    private OutputStream output;
    private BluetoothDevice device;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @PluginMethod
    public void listPaired(PluginCall call) {
        if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            call.reject("صلاحية Bluetooth غير ممنوحة. اسمح للتطبيق بالوصول إلى الأجهزة القريبة من إعدادات Android.");
            return;
        }
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) { call.reject("Bluetooth غير متوفر على هذا الهاتف"); return; }
            List<JSObject> list = new ArrayList<>();
            for (BluetoothDevice d : adapter.getBondedDevices()) {
                JSObject item = new JSObject();
                item.put("name", d.getName() == null ? "Bluetooth Printer" : d.getName());
                item.put("address", d.getAddress());
                list.add(item);
            }
            JSObject out = new JSObject();
            out.put("devices", list);
            call.resolve(out);
        } catch (Exception e) { call.reject(e.getMessage(), e); }
    }

    @PluginMethod
    public void connect(PluginCall call) {
        if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            call.reject("صلاحية Bluetooth غير ممنوحة. اسمح للتطبيق بالوصول إلى الأجهزة القريبة من إعدادات Android.");
            return;
        }
        String address = call.getString("address");
        if (address == null || address.isEmpty()) { call.reject("عنوان الطابعة غير محدد"); return; }
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) { call.reject("Bluetooth غير متوفر"); return; }
            disconnectInternal();
            device = adapter.getRemoteDevice(address);
            adapter.cancelDiscovery();
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
            socket.connect();
            output = socket.getOutputStream();
            JSObject out = new JSObject();
            out.put("success", true);
            out.put("deviceName", device.getName() == null ? "طابعة حرارية" : device.getName());
            call.resolve(out);
        } catch (Exception e) {
            disconnectInternal();
            call.reject("تعذر الاتصال بالطابعة: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void printRaw(PluginCall call) {
        if (output == null) { call.reject("لا توجد طابعة متصلة"); return; }
        String data = call.getString("data");
        if (data == null) { call.reject("بيانات الطباعة مفقودة"); return; }
        try {
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            output.write(bytes);
            output.flush();
            JSObject out = new JSObject(); out.put("success", true); call.resolve(out);
        } catch (Exception e) { call.reject("فشل إرسال بيانات الطباعة: " + e.getMessage(), e); }
    }


    @PluginMethod
    public void printReceipt(PluginCall call) {
        if (output == null) { call.reject("لا توجد طابعة متصلة"); return; }
        try {
            com.getcapacitor.JSArray lines = call.getArray("lines");
            int width = call.getInt("widthDots", 576);
            if (lines == null || lines.length() == 0) { call.reject("لا توجد بيانات للفواتير"); return; }
            if (width < 300) width = 384;
            if (width > 576) width = 576;

            StringBuilder text = new StringBuilder();
            for (int i = 0; i < lines.length(); i++) {
                String line = lines.optString(i, "");
                text.append(line == null ? "" : line).append("\n");
            }

            TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
            paint.setColor(Color.BLACK);
            paint.setTextSize(27f);
            paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));

            int contentWidth = width - 24;
            StaticLayout.Builder builder = StaticLayout.Builder.obtain(
                    text.toString(), 0, text.length(), paint, contentWidth
            )
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setIncludePad(true)
                    .setTextDirection(android.text.TextDirectionHeuristics.FIRSTSTRONG_RTL);
            StaticLayout layout = builder.build();

            Bitmap bitmap = Bitmap.createBitmap(width, Math.max(80, layout.getHeight() + 24), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            canvas.save();
            canvas.translate(12, 12);
            layout.draw(canvas);
            canvas.restore();

            byte[] raster = bitmapToEscPos(bitmap);
            output.write(raster);
            output.flush();
            bitmap.recycle();

            JSObject out = new JSObject();
            out.put("success", true);
            call.resolve(out);
        } catch (Exception e) {
            call.reject("فشل إنشاء/طباعة الفاتورة العربية: " + e.getMessage(), e);
        }
    }

    private byte[] bitmapToEscPos(Bitmap bitmap) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        out.write(new byte[]{0x1b, 0x40}); // init
        out.write(new byte[]{0x1b, 0x61, 0x01}); // center

        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int bytesPerRow = (width + 7) / 8;

        // GS v 0 raster bit image
        out.write(new byte[]{0x1d, 0x76, 0x30, 0x00});
        out.write(bytesPerRow & 0xff);
        out.write((bytesPerRow >> 8) & 0xff);
        out.write(height & 0xff);
        out.write((height >> 8) & 0xff);

        int[] pixels = new int[width];
        for (int y = 0; y < height; y++) {
            bitmap.getPixels(pixels, 0, width, 0, y, width, 1);
            for (int xByte = 0; xByte < bytesPerRow; xByte++) {
                int value = 0;
                for (int bit = 0; bit < 8; bit++) {
                    int x = xByte * 8 + bit;
                    if (x >= width) continue;
                    int c = pixels[x];
                    int r = Color.red(c);
                    int g = Color.green(c);
                    int b = Color.blue(c);
                    int gray = (r * 299 + g * 587 + b * 114) / 1000;
                    if (gray < 180) value |= (0x80 >> bit);
                }
                out.write(value);
            }
        }

        out.write(new byte[]{0x1b, 0x64, 0x03}); // feed
        out.write(new byte[]{0x1d, 0x56, 0x42, 0x00}); // cut if supported
        return out.toByteArray();
    }

    @PluginMethod
    public void disconnect(PluginCall call) { disconnectInternal(); call.resolve(); }

    private void disconnectInternal() {
        try { if (output != null) output.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        output = null; socket = null; device = null;
    }
}
