import { AppSettings, Product, Customer, Supplier, Expense, Invoice, PurchaseInvoice, CustomerPayment, SupplierTransaction } from '../types';

export const initialSettings: AppSettings = {
  exchangeRate: 15000, // 1 USD = 15,000 SYP
  baseCurrency: 'SYP',
  centerName: 'مركز العطايا لتوزيع المواد الغذائية',
  centerPhone: '0991234567',
  centerAddress: 'سوق الهال المركزي - مستودع رقم 14',
  receiptFooter: 'شكراً لتعاملكم مع مركز العطايا - البضاعة المباعة لا ترد بعد 3 أيام',
  themeMode: 'light',
};

export const initialProducts: Product[] = [
  {
    id: 'prod_1',
    name: 'زيت دوار الشمس نقي 1 لتر',
    unit: 'كرتونة',
    piecesPerCarton: 12,
    costCurrency: 'USD',
    purchaseCost: 18, // 18 USD per carton -> 1.5 USD per bottle
    totalPiecesInStock: 240, // 20 كرتونة
    createdAt: '2026-03-01T10:00:00',
    updatedAt: '2026-03-01T10:00:00',
  },
  {
    id: 'prod_2',
    name: 'سمنة نباتية ممتازة 2 كغ',
    unit: 'كرتونة',
    piecesPerCarton: 6,
    costCurrency: 'USD',
    purchaseCost: 22,
    totalPiecesInStock: 72, // 12 كرتونة
    createdAt: '2026-03-01T10:00:00',
    updatedAt: '2026-03-01T10:00:00',
  },
  {
    id: 'prod_3',
    name: 'سكر أبيض ناعم 1 كغ',
    unit: 'طرد',
    piecesPerCarton: 10,
    costCurrency: 'SYP',
    purchaseCost: 110000, // 110,000 SYP per package of 10
    totalPiecesInStock: 350, // 35 طرد
    createdAt: '2026-03-01T10:00:00',
    updatedAt: '2026-03-01T10:00:00',
  },
  {
    id: 'prod_4',
    name: 'أرز تايلندي حبة طويلة 1 كغ',
    unit: 'طرد',
    piecesPerCarton: 10,
    costCurrency: 'USD',
    purchaseCost: 14,
    totalPiecesInStock: 180, // 18 طرد
    createdAt: '2026-03-01T10:00:00',
    updatedAt: '2026-03-01T10:00:00',
  },
  {
    id: 'prod_5',
    name: 'تونة قطع فاخرة بالزيت 160غ',
    unit: 'كرتونة',
    piecesPerCarton: 48,
    costCurrency: 'USD',
    purchaseCost: 36, // 36 USD per 48 cans (0.75 USD/can)
    totalPiecesInStock: 480, // 10 كرتونة
    createdAt: '2026-03-01T10:00:00',
    updatedAt: '2026-03-01T10:00:00',
  },
  {
    id: 'prod_6',
    name: 'شاي سيلاني أسود سوبر 400غ',
    unit: 'كرتونة',
    piecesPerCarton: 24,
    costCurrency: 'USD',
    purchaseCost: 55,
    totalPiecesInStock: 120, // 5 كرتونة
    createdAt: '2026-03-01T10:00:00',
    updatedAt: '2026-03-01T10:00:00',
  },
  {
    id: 'prod_7',
    name: 'معكرونة سباغيتي إيطالية 500غ',
    unit: 'طرد',
    piecesPerCarton: 20,
    costCurrency: 'SYP',
    purchaseCost: 120000,
    totalPiecesInStock: 260, // 13 طرد
    createdAt: '2026-03-01T10:00:00',
    updatedAt: '2026-03-01T10:00:00',
  },
  {
    id: 'prod_8',
    name: 'رب بندورة مركز 800غ',
    unit: 'كرتونة',
    piecesPerCarton: 12,
    costCurrency: 'SYP',
    purchaseCost: 156000,
    totalPiecesInStock: 144, // 12 كرتونة
    createdAt: '2026-03-01T10:00:00',
    updatedAt: '2026-03-01T10:00:00',
  },
];

export const initialCustomers: Customer[] = [
  {
    id: 'cust_1',
    name: 'أبو بشير السمان',
    shopName: 'سوبرماركت البركة',
    phone: '0944112233',
    address: 'شارع الثورة - جانب المخبز الآلي',
    initialDebt: 450000,
    currency: 'SYP',
    notes: 'زبون قديم وموثوق - التوزيع أسبوعي كل ثلاثاء',
    createdAt: '2026-03-01T09:00:00',
  },
  {
    id: 'cust_2',
    name: 'عمر القاسم',
    shopName: 'بقالية النور والهدى',
    phone: '0988445566',
    address: 'حي الكرامة - الدوار الثاني',
    initialDebt: 280000,
    currency: 'SYP',
    notes: 'الدفع عند نهاية كل أسبوع',
    createdAt: '2026-03-01T09:30:00',
  },
  {
    id: 'cust_3',
    name: 'خالد النجار',
    shopName: 'ميني ماركت الفجر',
    phone: '0933778899',
    address: 'الميدان - قرب مدرسة النهضة',
    initialDebt: 150000,
    currency: 'SYP',
    notes: 'يفضل الشراء بالليرة السورية',
    createdAt: '2026-03-02T11:00:00',
  },
];

export const initialSuppliers: Supplier[] = [
  {
    id: 'supp_1',
    name: 'شركة الفيحاء للزيوت والسمون',
    company: 'الفيحاء للتجارة العامة',
    phone: '0112233445',
    initialDebt: 650, // 650 USD
    currency: 'USD',
    notes: 'مورد الزيوت والسمن النباتي - الدفع كاش أو حوالة',
    createdAt: '2026-03-01T08:00:00',
  },
  {
    id: 'supp_2',
    name: 'مؤسسة الدلتا للمعلبات والغذائيات',
    company: 'الدلتا للاستيراد والتوزيع',
    phone: '0119988776',
    initialDebt: 1200000, // SYP
    currency: 'SYP',
    notes: 'مورد التونة ورب البندورة والمعكرونة',
    createdAt: '2026-03-01T08:30:00',
  },
];

export const initialExpenses: Expense[] = [
  {
    id: 'exp_1',
    amount: 120000,
    currency: 'SYP',
    person: 'عبدالله',
    category: 'بنزين سيارة التوزيع',
    date: new Date().toISOString(),
    notes: 'تعبئة بنزين لسيارة التوزيع سوزوكي',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'exp_2',
    amount: 50000,
    currency: 'SYP',
    person: 'عبدالله',
    category: 'ضيافة ومصروف مستودع',
    date: new Date().toISOString(),
    notes: 'قهوة وشاي وماء للمستودع',
    createdAt: new Date().toISOString(),
  },
];

export const initialInvoices: Invoice[] = [
  {
    id: 'inv_1',
    invoiceNumber: 'INV-1001',
    customerId: 'cust_1',
    customerName: 'أبو بشير السمان',
    customerShop: 'سوبرماركت البركة',
    date: new Date().toISOString(),
    currency: 'SYP',
    items: [
      {
        productId: 'prod_1',
        productName: 'زيت دوار الشمس نقي 1 لتر',
        unit: 'كرتونة',
        piecesPerCarton: 12,
        cartons: 2,
        pieces: 0,
        totalPieces: 24,
        unitPrice: 295000,
        priceType: 'carton',
        itemTotal: 590000,
      },
      {
        productId: 'prod_3',
        productName: 'سكر أبيض ناعم 1 كغ',
        unit: 'طرد',
        piecesPerCarton: 10,
        cartons: 3,
        pieces: 4, // 3 طرود و 4 قطع
        totalPieces: 34,
        unitPrice: 125000, // 125,000 per package
        priceType: 'carton',
        itemTotal: 425000, // 3 * 125,000 + 4 * 12,500 = 375,000 + 50,000 = 425,000
      },
    ],
    subtotal: 1015000,
    discount: 15000,
    finalTotal: 1000000,
    paidAmount: 600000, // دفع 600 ألف نقداً
    remainingDebt: 400000, // بقي دين 400 ألف
    notes: 'تم التسليم بالسيارة',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const initialCustomerPayments: CustomerPayment[] = [
  {
    id: 'pay_1',
    customerId: 'cust_1',
    customerName: 'أبو بشير السمان',
    amount: 250000,
    currency: 'SYP',
    date: new Date().toISOString(),
    paymentMethod: 'cash',
    notes: 'دفعة نقدية مع السائق عبدالله',
    createdAt: new Date().toISOString(),
  },
];

export const initialSupplierTransactions: SupplierTransaction[] = [
  {
    id: 'st_1',
    supplierId: 'supp_1',
    supplierName: 'شركة الفيحاء للزيوت والسمون',
    type: 'payment',
    amount: 200,
    currency: 'USD',
    date: new Date().toISOString(),
    notes: 'سداد دفعة للمندوب نقداً بالدولار',
    createdAt: new Date().toISOString(),
  },
];

export const initialPurchaseInvoices: PurchaseInvoice[] = [
  {
    id: 'pur_1',
    invoiceNumber: 'PUR-1001',
    supplierId: 'supp_1',
    supplierName: 'شركة الفيحاء للزيوت والسمون',
    supplierCompany: 'الفيحاء للتجارة العامة',
    date: '2026-03-01T10:00:00',
    currency: 'USD',
    items: [
      {
        productId: 'prod_1',
        productName: 'زيت دوار الشمس نقي 1 لتر',
        unit: 'كرتونة',
        piecesPerCarton: 12,
        cartons: 20,
        pieces: 0,
        totalPieces: 240,
        costPerCarton: 18,
        itemTotal: 360,
      },
      {
        productId: 'prod_2',
        productName: 'سمنة نباتية ممتازة 2 كغ',
        unit: 'كرتونة',
        piecesPerCarton: 6,
        cartons: 12,
        pieces: 0,
        totalPieces: 72,
        costPerCarton: 22,
        itemTotal: 264,
      },
    ],
    subtotal: 624,
    discount: 24,
    finalTotal: 600,
    paidAmount: 200,
    remainingDebt: 400,
    notes: 'شحنة زيوت وسمن معتمدة',
    createdAt: '2026-03-01T10:00:00',
    updatedAt: '2026-03-01T10:00:00',
  },
];

