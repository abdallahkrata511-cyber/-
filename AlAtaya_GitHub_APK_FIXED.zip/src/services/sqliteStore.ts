import { Capacitor } from '@capacitor/core';
import { CapacitorSQLite } from '@capacitor-community/sqlite';

const DB_NAME = 'alataya_data';
const TABLE = 'app_state';
let db: any = null;
let ready = false;

export async function initSQLiteStore(): Promise<void> {
  if (ready || Capacitor.getPlatform() === 'web') return;
  try {
    const consistency = await CapacitorSQLite.checkConnectionsConsistency();
    const exists = await CapacitorSQLite.isConnection({ database: DB_NAME, readonly: false });
    if (consistency.result && exists.result) {
      db = await CapacitorSQLite.retrieveConnection({ database: DB_NAME, readonly: false });
    } else {
      await CapacitorSQLite.createConnection({ database: DB_NAME, encrypted: false, mode: 'no-encryption', version: 1, readonly: false });
      db = await CapacitorSQLite.retrieveConnection({ database: DB_NAME, readonly: false });
    }
    await db.open();
    await db.execute(`CREATE TABLE IF NOT EXISTS ${TABLE} (key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL);`);
    const existing = await db.query(`SELECT COUNT(*) AS count FROM ${TABLE}`);
    const count = Number(existing.values?.[0]?.count || 0);
    if (count === 0 && typeof localStorage !== 'undefined') {
      const statements: Array<{ statement: string; values: any[] }> = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!key || !key.startsWith('al_ataya_')) continue;
        const value = localStorage.getItem(key);
        if (value !== null) statements.push({ statement: `INSERT OR REPLACE INTO ${TABLE} (key, value) VALUES (?, ?);`, values: [key, value] });
      }
      if (statements.length) await db.executeSet(statements);
    }
    ready = true;
  } catch (error) {
    console.error('SQLite initialization failed; localStorage fallback remains active.', error);
  }
}


export async function hydrateAllLocalStorageFromSQLite(): Promise<void> {
  if (!ready || !db || typeof localStorage === 'undefined') return;
  try {
    const result = await db.query(`SELECT key, value FROM ${TABLE}`);
    for (const row of result.values ?? []) {
      if (typeof row.key === 'string' && row.key.startsWith('al_ataya_') && typeof row.value === 'string') {
        localStorage.setItem(row.key, row.value);
      }
    }
  } catch (error) {
    console.error('SQLite full hydration failed:', error);
  }
}

export async function hydrateLocalStorageFromSQLite(keys: string[]): Promise<void> {
  if (!ready || !db) return;
  try {
    const result = await db.query(`SELECT key, value FROM ${TABLE}`);
    for (const row of result.values ?? []) {
      if (keys.includes(row.key) && typeof row.value === 'string') localStorage.setItem(row.key, row.value);
    }
  } catch (error) {
    console.error('SQLite hydration failed:', error);
  }
}

export function persistToSQLite(key: string, value: unknown): void {
  if (!ready || !db) return;
  const json = JSON.stringify(value);
  void db.run(`INSERT INTO ${TABLE} (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value;`, [key, json])
    .catch((error: unknown) => console.error('SQLite save failed:', error));
}

export async function clearSQLiteStore(): Promise<void> {
  if (!ready || !db) return;
  await db.execute(`DELETE FROM ${TABLE};`);
}
