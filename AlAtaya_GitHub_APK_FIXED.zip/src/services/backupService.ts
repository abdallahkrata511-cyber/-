import { Capacitor } from '@capacitor/core';
import { Directory, Filesystem } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

function base64EncodeUtf8(value: string): string {
  const bytes = new TextEncoder().encode(value);
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(binary);
}

export async function exportBackupFile(json: string): Promise<{ success: boolean; error?: string }> {
  const filename = `AlAtaya_Backup_${new Date().toISOString().slice(0, 10)}.json`;

  if (Capacitor.getPlatform() === 'android') {
    try {
      const result = await Filesystem.writeFile({
        path: filename,
        data: base64EncodeUtf8(json),
        directory: Directory.Cache,
        recursive: true,
      });
      await Share.share({
        title: 'نسخة احتياطية - مركز العطايا',
        text: 'نسخة احتياطية لبيانات مركز العطايا',
        url: result.uri,
        dialogTitle: 'حفظ / مشاركة النسخة الاحتياطية',
      });
      return { success: true };
    } catch (error: any) {
      console.error('Android backup export failed', error);
      return { success: false, error: error?.message || 'تعذر حفظ النسخة الاحتياطية على Android' };
    }
  }

  try {
    const blob = new Blob([json], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    return { success: true };
  } catch (error: any) {
    return { success: false, error: error?.message || 'تعذر تنزيل النسخة الاحتياطية' };
  }
}
