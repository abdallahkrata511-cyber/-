import React, { useState, useEffect } from 'react';
import {
  Bluetooth,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Printer,
  Unplug,
  Settings2,
} from 'lucide-react';
import { BluetoothThermalPrinter } from '../../services/bluetoothPrinter';
import { Modal } from '../common/Modal';

interface BluetoothPrinterModalProps {
  isOpen: boolean;
  onClose: () => void;
  centerName?: string;
}

export const BluetoothPrinterModal: React.FC<BluetoothPrinterModalProps> = ({
  isOpen,
  onClose,
  centerName = 'مركز العطايا لتوزيع المواد الغذائية',
}) => {
  const [isConnected, setIsConnected] = useState(BluetoothThermalPrinter.isConnected());
  const [deviceName, setDeviceName] = useState<string | null>(
    BluetoothThermalPrinter.getConnectedDeviceName()
  );
  const [paperWidth, setPaperWidth] = useState<'58mm' | '80mm'>(
    BluetoothThermalPrinter.getPaperWidth()
  );
  const [isConnecting, setIsConnecting] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' | 'info' } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setIsConnected(BluetoothThermalPrinter.isConnected());
      setDeviceName(BluetoothThermalPrinter.getConnectedDeviceName());
      setPaperWidth(BluetoothThermalPrinter.getPaperWidth());
      setStatusMessage(null);
    }
  }, [isOpen]);

  const handleConnect = async () => {
    setIsConnecting(true);
    setStatusMessage({ text: 'جاري البحث عن طابعات البلوتوث المجاورة...', type: 'info' });

    try {
      const res = await BluetoothThermalPrinter.connect();
      if (res.success) {
        setIsConnected(true);
        setDeviceName(res.deviceName || 'طابعة حرارية');
        setStatusMessage({
          text: `تم الاتصال بنجاح بالطابعة: ${res.deviceName || 'طابعة حرارية'}`,
          type: 'success',
        });
      } else {
        setStatusMessage({
          text: res.error || 'فشل الاتصال بالطابعة',
          type: 'error',
        });
      }
    } catch (err: any) {
      setStatusMessage({
        text: err?.message || 'حدث خطأ غير متوقع',
        type: 'error',
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    await BluetoothThermalPrinter.disconnect();
    setIsConnected(false);
    setDeviceName(null);
    setStatusMessage({ text: 'تم قطع الاتصال بالطابعة', type: 'info' });
  };

  const handleTestPrint = async () => {
    setIsTesting(true);
    setStatusMessage({ text: 'جاري إرسال تذكرة فحص الطباعة...', type: 'info' });

    try {
      const ok = await BluetoothThermalPrinter.printTestReceipt(centerName);
      if (ok) {
        setStatusMessage({ text: 'تمت طباعة فحص الاتصال بنجاح ✓', type: 'success' });
      } else {
        setStatusMessage({
          text: 'تعذر إرسال أمر الطباعة. تأكد من تشغيل الطابعة وتوصيل الورق.',
          type: 'error',
        });
      }
    } catch (err: any) {
      setStatusMessage({ text: err?.message || 'خطأ في الطباعة', type: 'error' });
    } finally {
      setIsTesting(false);
    }
  };

  const handlePaperWidthChange = (width: '58mm' | '80mm') => {
    setPaperWidth(width);
    BluetoothThermalPrinter.setPaperWidth(width);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="إعدادات طابعة الفواتير (Bluetooth ESC/POS)"
      maxWidth="max-w-md"
    >
      <div className="space-y-4 text-slate-800 dark:text-slate-200">
        {/* Connection Status Card */}
        <div
          className={`p-4 rounded-2xl border transition-all ${
            isConnected
              ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800'
              : 'bg-slate-50 dark:bg-slate-900 border-slate-200 dark:border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`w-11 h-11 rounded-xl flex items-center justify-center ${
                  isConnected
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                }`}
              >
                <Bluetooth className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold">
                  {isConnected ? deviceName || 'طابعة حرارية' : 'غير متصل بأي طابعة'}
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {isConnected ? 'حالة الاتصال: متصل وجاهز للطباعة' : 'اضغط على اتصال لربط طابعة Bluetooth'}
                </p>
              </div>
            </div>

            {isConnected && (
              <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-900/60 px-2 py-1 rounded-full">
                <CheckCircle2 className="w-3.5 h-3.5" />
                متصل
              </span>
            )}
          </div>
        </div>

        {/* Paper Width Selection */}
        <div className="p-3.5 bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2">
          <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Settings2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>عرض ورق الطابعة الحرارية:</span>
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => handlePaperWidthChange('80mm')}
              className={`py-2 px-3 rounded-lg text-xs font-bold border transition ${
                paperWidth === '80mm'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              طابعة 80 ملم (العريضة)
            </button>
            <button
              type="button"
              onClick={() => handlePaperWidthChange('58mm')}
              className={`py-2 px-3 rounded-lg text-xs font-bold border transition ${
                paperWidth === '58mm'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                  : 'bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300'
              }`}
            >
              طابعة 58 ملم (المحمولة)
            </button>
          </div>
        </div>

        {/* Status Alert Message */}
        {statusMessage && (
          <div
            className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 ${
              statusMessage.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                : statusMessage.type === 'error'
                ? 'bg-red-50 text-red-800 dark:bg-red-950/50 dark:text-red-300 border border-red-200 dark:border-red-800'
                : 'bg-blue-50 text-blue-800 dark:bg-blue-950/50 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{statusMessage.text}</span>
          </div>
        )}

        {/* Actions Buttons */}
        <div className="space-y-2 pt-2">
          {!isConnected ? (
            <button
              type="button"
              onClick={handleConnect}
              disabled={isConnecting}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-xs transition active:scale-95 disabled:opacity-50 text-sm cursor-pointer"
            >
              {isConnecting ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Bluetooth className="w-4 h-4" />
              )}
              <span>{isConnecting ? 'جاري البحث والاتصال...' : 'بحث واتصال بطابعة بلوتوث'}</span>
            </button>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleTestPrint}
                disabled={isTesting}
                className="flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-xs transition active:scale-95 disabled:opacity-50 text-xs sm:text-sm cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>{isTesting ? 'جاري الطباعة...' : 'طباعة فحص تجريبي'}</span>
              </button>

              <button
                type="button"
                onClick={handleDisconnect}
                className="flex items-center justify-center gap-2 py-2.5 px-3 bg-slate-200 dark:bg-slate-800 hover:bg-red-100 hover:text-red-700 dark:hover:bg-red-950/50 dark:hover:text-red-300 text-slate-700 dark:text-slate-300 font-bold rounded-xl transition active:scale-95 text-xs sm:text-sm cursor-pointer"
              >
                <Unplug className="w-4 h-4" />
                <span>فصل الاتصال</span>
              </button>
            </div>
          )}

          <p className="text-[11px] text-slate-400 dark:text-slate-500 text-center leading-relaxed">
            يدعم بروتوكول ESC/POS القياسي المعتمد في جميع طابعات الفواتير المحمولة والمكتبية (58mm و 80mm).
          </p>
        </div>
      </div>
    </Modal>
  );
};
