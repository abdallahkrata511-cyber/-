import React, { useState, useMemo } from 'react';
import {
  Users,
  DollarSign,
  Coins,
  Package,
  ArrowDownLeft,
  ArrowUpRight,
  Plus,
  Trash2,
  Calendar,
  Clock,
  ShieldCheck,
  TrendingDown,
  FileSpreadsheet,
  AlertCircle,
  ShoppingBag,
} from 'lucide-react';
import { AppSettings, Currency, Product } from '../../types';
import { LocalDatabase } from '../../services/db';
import { GoodsWithdrawalModal } from '../cashbox/GoodsWithdrawalModal';
import { Modal } from '../common/Modal';
import { NumberInput } from '../common/NumberInput';

interface PartnersViewProps {
  settings: AppSettings;
  products: Product[];
  onUpdateSettings: (newSettings: AppSettings) => void;
  onRefreshData?: () => void;
}

export const PartnersView: React.FC<PartnersViewProps> = ({
  settings,
  products,
  onUpdateSettings,
  onRefreshData,
}) => {
  const [isGoodsModalOpen, setIsGoodsModalOpen] = useState(false);
  const [isCashWithdrawalOpen, setIsCashWithdrawalOpen] = useState(false);
  const [isCapitalModalOpen, setIsCapitalModalOpen] = useState(false);

  // Cash withdrawal form state
  const [withdrawer, setWithdrawer] = useState<'abdallah' | 'partner'>('partner');
  const [cashAmount, setCashAmount] = useState<number>(0);
  const [cashCurrency, setCashCurrency] = useState<Currency>('SYP');
  const [cashNotes, setCashNotes] = useState<string>('');
  const [cashDate, setCashDate] = useState<string>(new Date().toISOString().slice(0, 10));

  // Capital settings form state
  const [partnerName, setPartnerName] = useState<string>(settings.partnerName || 'الشريك');
  const [capitalUSD, setCapitalUSD] = useState<number>(settings.partnerCapitalUSD || 5000);

  // Filter state for transactions
  const [personFilter, setPersonFilter] = useState<'all' | 'partner' | 'abdallah'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'cash' | 'goods' | 'capital'>('all');

  const rate = settings.exchangeRate || 15000;

  // Partner summary
  const partnerSummary = useMemo(() => {
    return LocalDatabase.getPartnerAccountSummary();
  }, [settings, onRefreshData]);

  // Goods withdrawals list
  const goodsWithdrawals = useMemo(() => {
    return LocalDatabase.getGoodsWithdrawals();
  }, [onRefreshData, isGoodsModalOpen]);

  // Cash withdrawals list from cashbox
  const cashTransactions = useMemo(() => {
    return LocalDatabase.getCashTransactions().filter((t) => {
      return (
        t.category === 'partner_withdrawal' ||
        t.category === 'abdallah_withdrawal' ||
        t.category === 'capital_deposit' ||
        t.person === 'الشريك' ||
        t.person === 'عبدالله' ||
        t.person === (settings.partnerName || 'الشريك')
      );
    });
  }, [onRefreshData, isCashWithdrawalOpen]);

  // Combined operations log
  const operationsLog = useMemo(() => {
    const list: Array<{
      id: string;
      source: 'goods' | 'cash';
      person: 'partner' | 'abdallah';
      personLabel: string;
      type: 'سحب بضاعة' | 'سحب نقدي' | 'رأس مال';
      title: string;
      amountOriginal: number;
      currency: Currency;
      amountUSD: number;
      date: string;
      notes?: string;
    }> = [];

    // Add goods withdrawals
    for (const g of goodsWithdrawals) {
      const isPartner = g.person === 'partner';
      const usdVal = g.currency === 'USD' ? g.totalCost : g.totalCost / rate;
      list.push({
        id: 'goods_' + g.id,
        source: 'goods',
        person: g.person,
        personLabel: isPartner ? (settings.partnerName || 'الشريك') : 'عبدالله',
        type: 'سحب بضاعة',
        title: `سحب بضاعة: ${g.productName} (${g.cartons > 0 ? g.cartons + ' كرتونة ' : ''}${g.pieces > 0 ? g.pieces + ' قطعة' : ''}) بسعر التكلفة`,
        amountOriginal: g.totalCost,
        currency: g.currency,
        amountUSD: usdVal,
        date: g.date || g.createdAt,
        notes: g.notes,
      });
    }

    // Add cash transactions
    for (const c of cashTransactions) {
      const isPartner =
        c.category === 'partner_withdrawal' ||
        c.person === 'الشريك' ||
        c.person === (settings.partnerName || 'الشريك');
      const usdVal = c.currency === 'USD' ? c.amount : c.amount / rate;
      const opType = c.category === 'capital_deposit' ? 'رأس مال' : 'سحب نقدي';
      list.push({
        id: 'cash_' + c.id,
        source: 'cash',
        person: isPartner ? 'partner' : 'abdallah',
        personLabel: isPartner ? (settings.partnerName || 'الشريك') : 'عبدالله',
        type: opType,
        title: c.title || (c.category === 'capital_deposit' ? 'إيداع رأس مال' : 'سحب نقدي'),
        amountOriginal: c.amount,
        currency: c.currency,
        amountUSD: usdVal,
        date: c.date || c.createdAt,
        notes: c.notes,
      });
    }

    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [goodsWithdrawals, cashTransactions, rate, settings.partnerName]);

  // Filtered log
  const filteredLog = useMemo(() => {
    return operationsLog.filter((item) => {
      if (personFilter !== 'all' && item.person !== personFilter) return false;
      if (typeFilter === 'cash' && item.type !== 'سحب نقدي') return false;
      if (typeFilter === 'goods' && item.type !== 'سحب بضاعة') return false;
      if (typeFilter === 'capital' && item.type !== 'رأس مال') return false;
      return true;
    });
  }, [operationsLog, personFilter, typeFilter]);

  // Handle Save Cash Withdrawal
  const handleSaveCashWithdrawal = (e: React.FormEvent) => {
    e.preventDefault();
    if (cashAmount <= 0) return;

    const isPartner = withdrawer === 'partner';
    const personName = isPartner ? (settings.partnerName || 'الشريك') : 'عبدالله';

    LocalDatabase.addCashTransaction({
      type: 'out',
      category: isPartner ? 'partner_withdrawal' : 'abdallah_withdrawal',
      title: `سحب نقدي شخصي - ${personName}`,
      amount: cashAmount,
      currency: cashCurrency,
      date: cashDate ? new Date(cashDate).toISOString() : new Date().toISOString(),
      person: personName,
      notes: cashNotes.trim() || undefined,
    });

    setIsCashWithdrawalOpen(false);
    setCashAmount(0);
    setCashNotes('');
    if (onRefreshData) onRefreshData();
  };

  // Handle Save Capital
  const handleSaveCapital = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: AppSettings = {
      ...settings,
      hasPartner: true,
      partnerName: partnerName.trim() || 'الشريك',
      partnerCapitalUSD: Math.max(0, capitalUSD),
    };
    LocalDatabase.saveSettings(updated);
    onUpdateSettings(updated);
    setIsCapitalModalOpen(false);
    if (onRefreshData) onRefreshData();
  };

  // Handle Delete Operation
  const handleDeleteOperation = (item: (typeof operationsLog)[0]) => {
    const isConfirm = window.confirm(`هل أنت متأكد من حذف هذه الحركة: ${item.title}؟`);
    if (!isConfirm) return;

    if (item.source === 'goods') {
      const realId = item.id.replace('goods_', '');
      LocalDatabase.deleteGoodsWithdrawal(realId);
    } else {
      const realId = item.id.replace('cash_', '');
      LocalDatabase.deleteCashTransaction(realId);
    }
    if (onRefreshData) onRefreshData();
  };

  // Partner net current balance (Capital - Total Withdrawn)
  const partnerNetBalanceUSD = (settings.partnerCapitalUSD || 5000) - partnerSummary.partnerTotalWithdrawnUSD;

  return (
    <div className="space-y-6 pb-24 font-display">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-l from-[#153243] to-[#0f2430] p-6 rounded-3xl text-white shadow-xl border border-white/10">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-2xl bg-[#FFAA47] text-slate-950 flex items-center justify-center font-bold shadow-lg">
              <Users className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black">الشركاء ورأس المال والحسابات الجارية</h2>
              <p className="text-xs text-slate-300">
                إدارة مستقلة لرأس مال الشريك (5,000 $)، مسحوبات الشركاء بالتكلفة، وحساب عبدالله
              </p>
            </div>
          </div>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsGoodsModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-black text-xs transition cursor-pointer shadow-md"
          >
            <Package className="w-4 h-4" />
            <span>سحب بضاعة بالتكلفة</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setWithdrawer('partner');
              setIsCashWithdrawalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-700 text-white font-black text-xs transition cursor-pointer shadow-md"
          >
            <Coins className="w-4 h-4" />
            <span>سحب نقدي (كاش)</span>
          </button>

          <button
            type="button"
            onClick={() => setIsCapitalModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition cursor-pointer border border-white/10"
          >
            <DollarSign className="w-4 h-4 text-[#FFAA47]" />
            <span>إعدادات رأس المال</span>
          </button>
        </div>
      </div>

      {/* Main 2 Cards: Partner Account vs Abdallah Account */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* 1. Partner Account Card */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-purple-200 dark:border-purple-900/50 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-purple-100 dark:border-purple-900/40 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-purple-100 dark:bg-purple-950/80 text-purple-600 dark:text-purple-400 flex items-center justify-center font-bold">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-base text-slate-900 dark:text-white">
                  حساب {settings.partnerName || 'الشريك'} (الممول والشريك)
                </h3>
                <span className="text-xs text-slate-400">رأس المال الاستثماري والمسحوبات التراكمية</span>
              </div>
            </div>
            <span className="px-3 py-1 rounded-full bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300 font-black text-xs">
              رأس المال: ${(settings.partnerCapitalUSD || 5000).toLocaleString()}
            </span>
          </div>

          {/* Breakdown cards */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            {/* Cash Withdrawals */}
            <div className="p-3 rounded-2xl bg-purple-50/60 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/30">
              <span className="text-slate-500 dark:text-slate-400 block font-medium mb-1">
                مسحوبات نقدية (كاش الصندوق):
              </span>
              <div className="font-black text-sm text-slate-900 dark:text-slate-100">
                {partnerSummary.partnerCashSYP.toLocaleString()} <span className="text-[10px]">ل.س</span>
              </div>
              {partnerSummary.partnerCashUSD > 0 && (
                <div className="font-bold text-xs text-purple-600 dark:text-purple-400 mt-0.5">
                  + ${partnerSummary.partnerCashUSD.toLocaleString()}
                </div>
              )}
            </div>

            {/* Goods Withdrawals */}
            <div className="p-3 rounded-2xl bg-purple-50/60 dark:bg-purple-950/20 border border-purple-100 dark:border-purple-900/30">
              <span className="text-slate-500 dark:text-slate-400 block font-medium mb-1">
                مسحوبات بضاعة (بسعر التكلفة):
              </span>
              <div className="font-black text-sm text-slate-900 dark:text-slate-100">
                {partnerSummary.partnerGoodsSYP.toLocaleString()} <span className="text-[10px]">ل.س</span>
              </div>
              {partnerSummary.partnerGoodsUSD > 0 && (
                <div className="font-bold text-xs text-purple-600 dark:text-purple-400 mt-0.5">
                  + ${partnerSummary.partnerGoodsUSD.toLocaleString()}
                </div>
              )}
            </div>
          </div>

          {/* Summary Totals */}
          <div className="p-4 rounded-2xl bg-purple-950/5 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/50 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
              <span>إجمالي مسحوبات الشريك المقومة بالدولار:</span>
              <span className="text-red-600 dark:text-red-400 font-black">
                ${Math.round(partnerSummary.partnerTotalWithdrawnUSD).toLocaleString()}
              </span>
            </div>

            <div className="pt-2 border-t border-purple-200/80 dark:border-purple-900/60 flex items-center justify-between">
              <div>
                <span className="text-xs font-black text-purple-900 dark:text-purple-200 block">
                  صافي الحساب الجاري للشريك (رأس المال - المسحوبات):
                </span>
                <span className="text-[10px] text-slate-400">
                  المتبقي من رأس المال لصالح الشريك قبل الأرباح
                </span>
              </div>
              <div className="text-right">
                <span className="text-lg font-black text-purple-700 dark:text-purple-300">
                  ${Math.round(partnerNetBalanceUSD).toLocaleString()}
                </span>
                <div className="text-[10px] text-slate-400">
                  ~ {(Math.round(partnerNetBalanceUSD * rate)).toLocaleString()} ل.س
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 2. Abdallah Account Card */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl border border-amber-200 dark:border-amber-900/50 p-6 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-amber-100 dark:border-amber-900/40 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center font-bold">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-base text-slate-900 dark:text-white">
                  حساب عبدالله (الإدارة والتشغيل)
                </h3>
                <span className="text-xs text-slate-400">المسحوبات الشخصية النقدية وبضاعة المنزل</span>
              </div>
            </div>
            <span className="px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-black text-xs">
              مسحوبات خاصة
            </span>
          </div>

          {/* Breakdown cards */}
          <div className="grid grid-cols-2 gap-3 text-xs">
            {/* Cash Withdrawals */}
            <div className="p-3 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30">
              <span className="text-slate-500 dark:text-slate-400 block font-medium mb-1">
                مسحوبات نقدية (مصروف شخصي):
              </span>
              <div className="font-black text-sm text-slate-900 dark:text-slate-100">
                {partnerSummary.abdallahCashSYP.toLocaleString()} <span className="text-[10px]">ل.س</span>
              </div>
              {partnerSummary.abdallahCashUSD > 0 && (
                <div className="font-bold text-xs text-amber-600 dark:text-amber-400 mt-0.5">
                  + ${partnerSummary.abdallahCashUSD.toLocaleString()}
                </div>
              )}
            </div>

            {/* Goods Withdrawals */}
            <div className="p-3 rounded-2xl bg-amber-50/60 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30">
              <span className="text-slate-500 dark:text-slate-400 block font-medium mb-1">
                مسحوبات بضاعة (بسعر التكلفة):
              </span>
              <div className="font-black text-sm text-slate-900 dark:text-slate-100">
                {partnerSummary.abdallahGoodsSYP.toLocaleString()} <span className="text-[10px]">ل.س</span>
              </div>
              {partnerSummary.abdallahGoodsUSD > 0 && (
                <div className="font-bold text-xs text-amber-600 dark:text-amber-400 mt-0.5">
                  + ${partnerSummary.abdallahGoodsUSD.toLocaleString()}
                </div>
              )}
            </div>
          </div>

          {/* Summary Totals */}
          <div className="p-4 rounded-2xl bg-amber-950/5 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 dark:text-slate-300">
              <span>إجمالي مسحوبات عبدالله المقومة بالدولار:</span>
              <span className="text-red-600 dark:text-red-400 font-black">
                ${Math.round(partnerSummary.abdallahTotalWithdrawnUSD).toLocaleString()}
              </span>
            </div>

            <div className="pt-2 border-t border-amber-200/80 dark:border-amber-900/60 flex items-center justify-between">
              <div>
                <span className="text-xs font-black text-amber-900 dark:text-amber-200 block">
                  المعادل التقريبي بالليرة السورية:
                </span>
                <span className="text-[10px] text-slate-400">
                  تخصم من نصيب الأرباح عند توزيع الحسابات
                </span>
              </div>
              <span className="text-lg font-black text-amber-700 dark:text-amber-300">
                {(Math.round(partnerSummary.abdallahTotalWithdrawnUSD * rate)).toLocaleString()} ل.س
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Operations Ledger & History */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div>
            <h3 className="text-base font-black text-slate-900 dark:text-white flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-purple-600" />
              <span>سجل حركات الشركاء والمسحوبات</span>
            </h3>
            <p className="text-xs text-slate-500">
              جميع الحركات المسجلة على حساب الشريك أو عبدالله مرتبة زمنياً
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Person Filter */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-bold">
              <button
                type="button"
                onClick={() => setPersonFilter('all')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  personFilter === 'all'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                الكل
              </button>
              <button
                type="button"
                onClick={() => setPersonFilter('partner')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  personFilter === 'partner'
                    ? 'bg-purple-600 text-white shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                {settings.partnerName || 'الشريك'}
              </button>
              <button
                type="button"
                onClick={() => setPersonFilter('abdallah')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  personFilter === 'abdallah'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                عبدالله
              </button>
            </div>

            {/* Type Filter */}
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-bold">
              <button
                type="button"
                onClick={() => setTypeFilter('all')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  typeFilter === 'all'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                جميع الأنواع
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('cash')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  typeFilter === 'cash'
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                نقد كاش
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('goods')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  typeFilter === 'goods'
                    ? 'bg-amber-600 text-white shadow-xs'
                    : 'text-slate-500'
                }`}
              >
                بضاعة بالتكلفة
              </button>
            </div>
          </div>
        </div>

        {/* Ledger Items */}
        {filteredLog.length === 0 ? (
          <div className="py-12 text-center text-slate-400">
            <FileSpreadsheet className="w-10 h-10 mx-auto opacity-30 mb-2" />
            <p className="text-sm font-bold">لا توجد حركات مسجلة للشركاء مطابقة للفلتر</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filteredLog.map((item) => {
              const isPartner = item.person === 'partner';
              const dateObj = new Date(item.date);
              const dateFormatted = dateObj.toLocaleDateString('ar-SY');
              const timeFormatted = dateObj.toLocaleTimeString('ar-SY', {
                hour: '2-digit',
                minute: '2-digit',
              });

              return (
                <div
                  key={item.id}
                  className="p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-900/50 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        item.source === 'goods'
                          ? 'bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300'
                          : 'bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300'
                      }`}
                    >
                      {item.source === 'goods' ? (
                        <Package className="w-4 h-4" />
                      ) : (
                        <Coins className="w-4 h-4" />
                      )}
                    </div>

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-bold text-slate-900 dark:text-white">
                          {item.title}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                            isPartner
                              ? 'bg-purple-100 dark:bg-purple-950 text-purple-800 dark:text-purple-300'
                              : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                          }`}
                        >
                          {item.personLabel}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {item.type}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          <span>{dateFormatted}</span>
                        </span>
                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" />
                          <span>{timeFormatted}</span>
                        </span>
                        {item.notes && (
                          <span className="text-slate-500 truncate max-w-xs">
                            ملاحظة: {item.notes}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-200 dark:border-slate-800">
                    <div className="text-right">
                      <div className="text-base font-black font-mono text-red-600 dark:text-red-400">
                        -{item.amountOriginal.toLocaleString()}{' '}
                        <span className="text-xs font-bold">
                          {item.currency === 'USD' ? '$' : 'ل.س'}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400">
                        ~ ${Math.round(item.amountUSD).toLocaleString()}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleDeleteOperation(item)}
                      className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 rounded-xl transition cursor-pointer"
                      title="حذف الحركة"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Modal 1: Goods Withdrawal Modal */}
      <GoodsWithdrawalModal
        isOpen={isGoodsModalOpen}
        onClose={() => setIsGoodsModalOpen(false)}
        products={products}
        settings={settings}
        onSuccess={() => {
          setIsGoodsModalOpen(false);
          if (onRefreshData) onRefreshData();
        }}
      />

      {/* Modal 2: Cash Withdrawal Modal */}
      <Modal
        isOpen={isCashWithdrawalOpen}
        onClose={() => setIsCashWithdrawalOpen(false)}
        title="تسجيل سحب نقدي (كاش) للشريك أو عبدالله"
        subtitle="يخصم المبلغ فوراً من الصندوق ويسجل على الحساب الجاري للشخص"
      >
        <form onSubmit={handleSaveCashWithdrawal} className="space-y-4 font-display">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              صاحب السحب النقدي:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setWithdrawer('partner')}
                className={`p-3 rounded-2xl border font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                  withdrawer === 'partner'
                    ? 'border-purple-600 bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>{settings.partnerName || 'الشريك'}</span>
              </button>

              <button
                type="button"
                onClick={() => setWithdrawer('abdallah')}
                className={`p-3 rounded-2xl border font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2 ${
                  withdrawer === 'abdallah'
                    ? 'border-amber-600 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 shadow-xs'
                    : 'border-slate-200 dark:border-slate-700 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                <span>عبدالله</span>
              </button>
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                المبلغ المسحوب:
              </label>
              <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-lg text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setCashCurrency('SYP')}
                  className={`px-3 py-1 rounded-md transition cursor-pointer ${
                    cashCurrency === 'SYP'
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  ل.س سوري
                </button>
                <button
                  type="button"
                  onClick={() => setCashCurrency('USD')}
                  className={`px-3 py-1 rounded-md transition cursor-pointer ${
                    cashCurrency === 'USD'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  $ دولار
                </button>
              </div>
            </div>
            <NumberInput
              value={cashAmount}
              onChange={(val) => setCashAmount(val)}
              min={0}
              step={cashCurrency === 'USD' ? 5 : 1000}
              placeholder="أدخل المبلغ المسحوب..."
              className="text-base font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              تاريخ السحب:
            </label>
            <input
              type="date"
              value={cashDate}
              onChange={(e) => setCashDate(e.target.value)}
              className="w-full h-11 px-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-semibold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              البيان / سبب السحب (اختياري):
            </label>
            <input
              type="text"
              value={cashNotes}
              onChange={(e) => setCashNotes(e.target.value)}
              placeholder="مثال: سحب مصاريف شخصية، دفعة على الحساب..."
              className="w-full h-11 px-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm"
            />
          </div>

          <button
            type="submit"
            disabled={cashAmount <= 0}
            className="w-full py-3.5 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-black rounded-2xl shadow-md transition cursor-pointer text-sm"
          >
            تأكيد تسجيل السحب النقدي
          </button>
        </form>
      </Modal>

      {/* Modal 3: Capital Settings Modal */}
      <Modal
        isOpen={isCapitalModalOpen}
        onClose={() => setIsCapitalModalOpen(false)}
        title="تعديل رأس مال الشريك"
        subtitle="حفظ رأس المال الأساسي بالدولار (5,000 $ افتراضياً)"
      >
        <form onSubmit={handleSaveCapital} className="space-y-4 font-display">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              اسم الشريك:
            </label>
            <input
              type="text"
              value={partnerName}
              onChange={(e) => setPartnerName(e.target.value)}
              placeholder="مثال: أبو عمر، الشريك..."
              className="w-full h-11 px-3 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm font-bold"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              رأس مال الشريك الأساسي بالدولار ($):
            </label>
            <NumberInput
              value={capitalUSD}
              onChange={(val) => setCapitalUSD(val)}
              min={0}
              step={100}
              className="text-base font-bold"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              الافتراضي هو 5,000 دولار أمريكي.
            </p>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-[#153243] hover:bg-[#1f455b] text-white font-black rounded-2xl shadow-md transition cursor-pointer text-sm"
          >
            حفظ تعديلات رأس المال
          </button>
        </form>
      </Modal>
    </div>
  );
};
