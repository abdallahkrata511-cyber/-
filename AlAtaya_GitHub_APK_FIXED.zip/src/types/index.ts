export type Currency = 'SYP' | 'USD';

export type ThemeMode = 'light' | 'dark' | 'system';

export interface AppSettings {
  exchangeRate: number; // 1 USD = X SYP (e.g. 15000)
  previousExchangeRate?: number; // آخر سعر قبل التعديل، لتوضيح أثر تغير الصرف على التقييم
  baseCurrency: Currency;
  centerName: string;
  centerPhone: string;
  centerAddress: string;
  receiptFooter: string;
  themeMode?: ThemeMode;
  initialCashSYP?: number; // رصيد الصندوق الافتتاحي بالليرة السورية
  initialCashUSD?: number; // رصيد الصندوق الافتتاحي بالدولار
  hasPartner?: boolean; // هل يوجد شريك في المشروع
  partnerName?: string; // اسم الشريك (مثل: أبو عمر)
  partnerCapitalUSD?: number; // رأس مال الشريك المدفوع بالدولار (5000 USD افتراضياً)
}

export interface Product {
  id: string;
  name: string;
  unit: string; // e.g., 'كرتونة', 'طرد', 'شوال', 'صندوق'
  piecesPerCarton: number; // عدد القطع داخل الكرتونة (مثلاً 12)
  costCurrency: Currency; // USD or SYP
  purchaseCost: number; // تكلفة شراء الكرتونة بالعملة المحددة
  sellingPrice?: number; // سعر البيع المحدد مسبقاً
  sellingPriceCurrency?: Currency; // عملة سعر البيع المحدد
  totalPiecesInStock: number; // إجمالي القطع المتوفرة في المستودع
  barcode?: string;
  notes?: string;
  isArchived?: boolean; // أرشفة المنتج للحفاظ على الفواتير القديمة
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  shopName: string; // اسم المحل / البقالية
  address: string;
  initialDebt: number; // بالعملة القديمة أو SYP
  initialDebtUSD?: number; // رصيد سابق بالدولار
  currency: Currency;
  notes?: string;
  createdAt: string;
}

export interface InvoiceItem {
  productId: string;
  productName: string;
  unit: string;
  piecesPerCarton: number;
  cartons: number; // عدد الكراتين
  pieces: number; // عدد القطع الإضافية
  totalPieces: number; // cartons * piecesPerCarton + pieces
  unitPrice: number; // سعر بيع الكرتونة المحدد يدوياً
  priceType: 'carton' | 'piece';
  itemTotal: number; // إجمالي البند
  costPerCartonAtSale?: number;
  costCurrencyAtSale?: Currency;
}

export interface Invoice {
  id: string;
  invoiceNumber: string; // e.g., "INV-00101"
  customerId: string;
  customerName: string;
  customerShop?: string;
  date: string; // YYYY-MM-DDTHH:mm:ss
  currency: Currency;
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  finalTotal: number;
  paidAmount: number; // المدفوع نقداً عند البيع
  remainingDebt: number; // المتبقي ديناً على العميل
  previousCustomerBalance?: number; // الرصيد السابق للعميل المسجل لحظة إنشاء الفاتورة
  isFixedUSD?: boolean; // تثبيت سعر الفاتورة بالدولار
  fixedExchangeRate?: number; // سعر التثبيت بالليرة لكل دولار (مثلاً 13,500)
  fixedUSDAmount?: number; // قيمة الفاتورة المحسوبة بالدولار ومثبتة
  exchangeRate?: number; // سعر الصرف المعتمد للفاتورة
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PurchaseInvoiceItem {
  productId: string;
  productName: string;
  unit: string;
  piecesPerCarton: number;
  cartons: number; // عدد الكراتين المشتراة
  pieces: number; // قطع إضافية مشتراة
  totalPieces: number; // cartons * piecesPerCarton + pieces
  costPerCarton: number; // تكلفة شراء الكرتونة بالعملة المحددة
  itemTotal: number; // إجمالي تكلفة البند
}

export interface PurchaseInvoice {
  id: string;
  invoiceNumber: string; // e.g., "PUR-1001"
  supplierId: string;
  supplierName: string;
  supplierCompany?: string;
  date: string; // YYYY-MM-DDTHH:mm:ss
  currency: Currency;
  items: PurchaseInvoiceItem[];
  subtotal: number;
  discount: number;
  finalTotal: number;
  paidAmount: number; // المبلغ المسدد للمورد نقداً عند الشراء
  remainingDebt: number; // المتبقي ديناً للمورد من هذه الفاتورة
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CustomerPayment {
  id: string;
  customerId: string;
  customerName: string;
  amount: number;
  currency: Currency;
  date: string;
  paymentMethod: 'cash' | 'transfer';
  notes?: string;
  createdAt: string;
}

export interface Supplier {
  id: string;
  name: string;
  company: string; // الشركة أو المعمل
  phone: string;
  initialDebt: number; // بالليرة السورية
  initialDebtUSD?: number; // بالدولار
  currency: Currency;
  notes?: string;
  createdAt: string;
}

export interface SupplierTransaction {
  id: string;
  supplierId: string;
  supplierName: string;
  type: 'purchase' | 'payment'; // مشتريات (زيادة دين) أو دفعة (سداد)
  amount: number;
  currency: Currency;
  date: string;
  notes?: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  amount: number;
  currency: Currency;
  person: string; // الشخص المسؤول عن الصرف (افتراضياً: عبدالله)
  category: string; // بنزين، صيانة، كهرباء، إيجار، عمال، أخرى
  date: string;
  notes?: string;
  createdAt: string;
}

// عملية شراء دولار من الليرة السورية
export interface UsdPurchase {
  id: string;
  amountUSD: number; // مثلاً 100 USD
  exchangeRate: number; // مثلاً 13500 SYP
  costSYP: number; // 1,350,000 SYP
  date: string;
  notes?: string;
  createdAt: string;
}

// عملية سحب بضاعة من المخزون لعبدالله أو الشريك (بسعر التكلفة)
export interface GoodsWithdrawal {
  id: string;
  person: 'abdallah' | 'partner';
  productId: string;
  productName: string;
  unit: string;
  cartons: number;
  pieces: number;
  totalPieces: number;
  unitCost: number; // تكلفة الكرتونة
  currency: Currency; // عملة التكلفة (USD أو SYP)
  totalCost: number; // القيمة الإجمالية المسجلة على الحساب الجاري
  date: string;
  notes?: string;
  createdAt: string;
}

// مساهمة رأس مال الشريك
export interface PartnerCapital {
  id: string;
  partnerName: string;
  amountUSD: number; // 5000 USD
  date: string;
  notes?: string;
  createdAt: string;
}

export type CashTransactionCategory =
  | 'capital_deposit'     // إيداع نقدي / رأس مال / تمويل
  | 'sale_income'         // مقبوضات بيع نقدي
  | 'customer_payment'    // دفعة نقدية من عميل
  | 'supplier_payment'    // سداد دفعة لمورد
  | 'purchase_cash'       // مشتريات نقدية مدفوعة
  | 'operating_expense'   // مصروف تشغيلي (وقود، صيانة، إلخ)
  | 'usd_purchase'        // شراء دولار (تحويل عملة بين الأرصدة)
  | 'usd_sale'            // بيع دولار (تحويل عملة)
  | 'abdallah_withdrawal' // سحب نقدي - عبدالله
  | 'partner_withdrawal'  // سحب نقدي - الشريك
  | 'special_expense'     // مصروف خاص (غير تشغيلي)
  | 'other_withdrawal'    // سحب نقدي آخر
  | 'other_deposit';      // إيداع نقدي آخر

export interface CashTransaction {
  id: string;
  type: 'in' | 'out'; // داخل أم خارج من الصندوق
  category: CashTransactionCategory;
  title: string;
  amount: number;
  currency: Currency;
  date: string; // ISO string
  person?: string; // عبدالله، الشريك، السائق، إلخ
  notes?: string;
  relatedEntityId?: string; // ربط مع فاتورة بيع/شراء أو سند قبض/دفع أو عملية شراء دولار
  exchangeRate?: number; // سعر الصرف في حال كانت العملية تحويل عملة
  createdAt: string;
}

export type ActiveTab =
  | 'dashboard'
  | 'inventory_audit'     // الجرد اليومي الشامل
  | 'usd_exchange'        // قسم شراء الدولار
  | 'partners'            // الشركاء ورأس المال والحسابات الجارية
  | 'cashbox'
  | 'sales'
  | 'purchases'
  | 'customers'
  | 'products'
  | 'suppliers'
  | 'expenses';

export interface InventoryItemBreakdown {
  id: string;
  name: string;
  unit: string;
  piecesPerCarton: number;
  totalPieces: number;
  cartons: number;
  loosePieces: number;
  costCurrency: Currency;
  unitCost: number; // cost per carton
  pieceCost: number; // cost per piece
  totalCostOriginal: number; // total in original currency
  equivalentUSD: number; // converted to USD at audit rate
  equivalentSYP: number; // converted to SYP at audit rate
}

export interface ProjectReconciliation {
  totalAssetsUSD: number;
  totalLiabilitiesUSD: number;
  actualNetWorthUSD: number; // الأصول - الالتزامات
  initialCapitalUSD: number; // رأس مال الشريك (5000$)
  operatingProfitUSD: number; // أرباح المبيعات - المصاريف
  partnerTotalWithdrawnUSD: number;
  abdallahTotalWithdrawnUSD: number;
  totalWithdrawalsUSD: number; // مسحوبات الشركاء مجتمعة
  expectedEquityUSD: number; // رأس المال + الأرباح - المسحوبات
  unexplainedDifferenceUSD: number; // الفرق غير المفسر (إن وجد)
  isBalanced: boolean;
}

export interface DailyInventoryAudit {
  timestamp: string;
  asOfDate: string;
  exchangeRate: number;
  // Cash
  cashSYP: number;
  cashUSD: number;
  cashTotalInUSD: number;
  // Customers
  customerDebtSYP: number;
  customerDebtUSD: number;
  customerDebtsInUSD: number;
  customerDebtsList: Array<{
    id: string;
    name: string;
    shopName?: string;
    syp: number;
    usd: number;
    totalInUSD: number;
  }>;
  // Suppliers
  supplierDebtSYP: number;
  supplierDebtUSD: number;
  supplierDebtsInUSD: number;
  supplierDebtsList: Array<{
    id: string;
    name: string;
    company?: string;
    syp: number;
    usd: number;
    totalInUSD: number;
  }>;
  // Inventory (Independent SYP & USD classifications)
  inventoryCostUSD: number; // items costed in USD
  inventoryCostSYP: number; // items costed in SYP
  totalInventoryInUSD: number; // combined at audit exchange rate
  totalInventoryInSYP: number; // combined at audit exchange rate
  totalProductsCount: number;
  totalPiecesCount: number;
  inventorySYPItems: InventoryItemBreakdown[];
  inventoryUSDItems: InventoryItemBreakdown[];
  // Detailed operational reports
  expensesList?: Array<{
    id: string;
    category: string;
    person: string;
    amount: number;
    currency: Currency;
    date: string;
    notes?: string;
  }>;
  goodsWithdrawalsList?: Array<{
    id: string;
    person: 'abdallah' | 'partner';
    productName: string;
    totalPieces: number;
    totalCost: number;
    currency: Currency;
    date: string;
    notes?: string;
  }>;
  cashWithdrawalsList?: Array<{
    id: string;
    person: string;
    title: string;
    amount: number;
    currency: Currency;
    date: string;
    notes?: string;
  }>;
  // Partners
  partnerSummary: {
    partnerName: string;
    totalCapitalUSD: number;
    partnerCashSYP: number;
    partnerCashUSD: number;
    partnerGoodsSYP: number;
    partnerGoodsUSD: number;
    partnerTotalWithdrawnUSD: number;
    abdallahCashSYP: number;
    abdallahCashUSD: number;
    abdallahGoodsSYP: number;
    abdallahGoodsUSD: number;
    abdallahTotalWithdrawnUSD: number;
  };
  // Final Project Balance & Matching
  totalAssetsUSD: number;
  totalLiabilitiesUSD: number;
  netProjectWorthUSD: number;
  netProjectWorthSYP: number;
  initialCapitalUSD: number;
  totalWithdrawalsUSD: number;
  netProfitOrLossUSD: number;
  // Expected profit from current inventory at current selling prices
  expectedInventorySalesUSD?: number;
  expectedInventorySalesSYP?: number;
  expectedInventoryProfitUSD?: number;
  expectedInventoryProfitSYP?: number;
  exchangeRateEffectUSD?: number;
  // Strict Project Reconciliation
  reconciliation: ProjectReconciliation;
}


