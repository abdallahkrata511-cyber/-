import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { initSQLiteStore, hydrateAllLocalStorageFromSQLite } from './services/sqliteStore';

async function bootstrap() {
  // On Android, hydrate localStorage from the real SQLite database before React
  // reads any business data. This prevents the app from appearing empty/stale
  // after restart or after restoring a backup.
  await initSQLiteStore();
  await hydrateAllLocalStorageFromSQLite();

  createRoot(document.getElementById('root')!).render(
    <StrictMode>
      <App />
    </StrictMode>,
  );
}

void bootstrap();
